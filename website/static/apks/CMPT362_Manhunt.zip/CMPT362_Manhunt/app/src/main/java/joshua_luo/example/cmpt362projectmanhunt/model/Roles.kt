package joshua_luo.example.cmpt362projectmanhunt.model

/**
 * Possible roles for the player
 */

enum class Roles {
    Hunter,
    Runner,
    Spectator
}