package joshua_luo.example.cmpt362projectmanhunt.model

/**
 * Simple latitude/longitude point
 */
data class Point(
    val latitude: Double,
    val longitude: Double
)
