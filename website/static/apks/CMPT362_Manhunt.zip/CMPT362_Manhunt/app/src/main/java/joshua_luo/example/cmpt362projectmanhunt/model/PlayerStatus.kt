package joshua_luo.example.cmpt362projectmanhunt.model

/**
 * Possible statuses for the player to be in
 */

enum class PlayerStatus {
    Alive,
    Caught,
    Dead
}